//
//  ViewController.m
//  goodfixpush
//
//  Created by 潘强 on 2018/9/30.
//  Copyright © 2018年 pan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    
}


@end
