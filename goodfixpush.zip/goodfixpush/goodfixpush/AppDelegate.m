//
//  AppDelegate.m
//  goodfixpush
//
//  Created by 潘强 on 2018/9/30.
//  Copyright © 2018年 pan. All rights reserved.
//

#import "AppDelegate.h"
#import <UMCommon/UMCommon.h>
#import <UMPush/UMessage.h>
#import <UserNotifications/UserNotifications.h>

#import "HomeViewController.h"
#import "secondViewController.h"

/*1、UMNENG_APPKEY为友盟平台产生的appkey
  2、Bundle Identifier需要和Apple开发者账号中一致
 */
#define UMNENG_APPKEY  @"5bb06953f1f556fffa00006a"

@interface AppDelegate ()<UNUserNotificationCenterDelegate,UIAlertViewDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window.rootViewController = [[HomeViewController alloc]init];
    
    //友盟推送:
    [UMConfigure setEncryptEnabled:YES];
    [UMConfigure setLogEnabled:YES];
    
    [UMConfigure initWithAppkey:UMNENG_APPKEY channel:launchOptions];
    //iOS10接收消息的代理
    [UNUserNotificationCenter currentNotificationCenter].delegate = self;
    UMessageRegisterEntity *entity = [[UMessageRegisterEntity alloc]init];
    entity.types = UMessageAuthorizationOptionBadge|UMessageAuthorizationOptionAlert;
    [UNUserNotificationCenter currentNotificationCenter].delegate = self;
    [UMessage registerForRemoteNotificationsWithLaunchOptions:launchOptions Entity:entity completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (granted) {
            NSLog(@"用户选择了接收push消息");
        }else{
            NSLog(@"用户拒绝接收push消息");
        }
    }];
    return YES;
}
//注册通知，设备token
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(nonnull NSData *)deviceToken{
    NSLog(@"deviceToken======%@",[[[[deviceToken description] stringByReplacingOccurrencesOfString: @"<" withString: @""]
                                   stringByReplacingOccurrencesOfString: @">" withString: @""]
                                  stringByReplacingOccurrencesOfString: @" " withString: @""]);
    NSString *token =
    [[[[deviceToken description] stringByReplacingOccurrencesOfString:@"<"
                                                           withString:@""]
      stringByReplacingOccurrencesOfString:@">"
      withString:@""]
     stringByReplacingOccurrencesOfString:@" "
     withString:@""];
    [UMessage registerDeviceToken:deviceToken];
}
//iOS10以下接收处理
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(nonnull NSDictionary *)userInfo
{
    if (application.applicationState == UIApplicationStateActive)
    { // 应用在前台        // 最好先弹出一个 Alert，如下图片，今日头条，当你在浏览新闻，应用在前台，他就会弹出一个 Alert，告知你是否查看详情
        NSLog(@"应用在前台");
        //自定义弹出框
        UIAlertController *alertCon = [UIAlertController alertControllerWithTitle:nil message:@"提示" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"前台确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            //
            NSLog(@"前台keyi");
            [self.window.rootViewController presentViewController:[[secondViewController alloc]init] animated:YES completion:nil];
        }];
        [alertCon addAction:action2];
        [self.window.rootViewController presentViewController:alertCon animated:YES completion:nil];
        
    }    else    { // 应用在后台         // 应用在后台点击通知，直接跳转 web 页面
        NSLog(@"应用在后台");
        NSString *url = userInfo[@"url"];
        if (url){
            [self.window.rootViewController presentViewController:[[secondViewController alloc]init] animated:YES completion:nil];
        }
    }
}
//APP处于前台时接收处理
-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler
{
    NSDictionary * userInfo = notification.request.content.userInfo;
    _userInfo = userInfo;
    NSLog(@"%@",_userInfo);
    /*
     {
     aps =     {
     alert =         {
     body = 78973;
     subtitle = 000;
     title = "\Ud83d\Udcb0\Ud83d\Udc4c\U4e5f\U662f\U6765\U5427";
     };
     sound = default;
     };
     d = uu4go69153931180364410;
     p = 0;
     }
     */
    //可根据_userInfo内容不同来跳转到不同页面，具体判断自己根据实际情况来写
    if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        
        //自定义弹出框
        UIAlertController *alertCon = [UIAlertController alertControllerWithTitle:nil message:@"提示" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"前台确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            //
            NSLog(@"前台keyi");
            [self.window.rootViewController presentViewController:[[secondViewController alloc]init] animated:YES completion:nil];
        }];
        [alertCon addAction:action2];
        [self.window.rootViewController presentViewController:alertCon animated:YES completion:nil];
        //应用处于前台时的远程推送接受
        //关闭友盟自带的弹出框
        [UMessage setAutoAlert:NO];
        //必须加这句代码
        [UMessage didReceiveRemoteNotification:userInfo];
    }else{
        //应用处于前台时的本地推送接受
    }
    //当应用处于前台时提示设置，需要哪个可以设置哪一个
    completionHandler(UNNotificationPresentationOptionSound|UNNotificationPresentationOptionBadge|UNNotificationPresentationOptionAlert);
}
//APP处于后台时接收处理
-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler
{
    NSDictionary * userInfo = response.notification.request.content.userInfo;
    _userInfo = userInfo;
    if([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        //自定义弹出框
        UIAlertController *alertCon = [UIAlertController alertControllerWithTitle:nil message:@"提示" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"后台确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            //
            NSLog(@"前台keyi");
            [self.window.rootViewController presentViewController:[[secondViewController alloc]init] animated:YES completion:nil];
        }];
        [alertCon addAction:action2];
        [self.window.rootViewController presentViewController:alertCon animated:YES completion:nil];
        //应用处于后台时的远程推送接受
        //必须加这句代码
        [UMessage didReceiveRemoteNotification:userInfo];
        
    }else{
        //应用处于后台时的本地推送接受
    }
    
    [self.delegate didGetPushNotifi];
}

//这里需要遵守alertview的代理，自己添加<UNUserNotificationCenterDelegate,UIAlertViewDelegate>
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    //点击去看看
    if (buttonIndex==1) {
        [self.delegate didGetPushNotifi];
    }
    
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
