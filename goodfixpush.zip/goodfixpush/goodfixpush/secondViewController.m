//
//  secondViewController.m
//  goodfixpush
//
//  Created by pan on 2018/10/11.
//  Copyright © 2018年 pan. All rights reserved.
//

#import "secondViewController.h"

@interface secondViewController ()

@end

@implementation secondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *_lockBtn = [[UIButton alloc] initWithFrame:CGRectMake(100, 350, 100, 30)];
    [_lockBtn setTitle:@"第二页" forState:UIControlStateNormal];
    [_lockBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_lockBtn addTarget:self action:@selector(slot_lockClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_lockBtn];
}
-(void)slot_lockClicked{
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
