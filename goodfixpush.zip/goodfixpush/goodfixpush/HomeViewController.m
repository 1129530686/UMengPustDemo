//
//  HomeViewController.m
//  goodfixpush
//
//  Created by pan on 2018/10/11.
//  Copyright © 2018年 pan. All rights reserved.
//

#import "HomeViewController.h"
#import "secondViewController.h"
#import "AppDelegate.h"

@interface HomeViewController ()
@property (nonatomic,strong) AppDelegate* appDele;
@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor grayColor];
    self.navigationItem.title = @"首页";
    
    UIButton *_lockBtn = [[UIButton alloc] initWithFrame:CGRectMake(50, 200, 100, 30)];
    [_lockBtn setTitle:@"下一页" forState:UIControlStateNormal];
    [_lockBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_lockBtn addTarget:self action:@selector(slot_lockClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_lockBtn];
}

-(void)slot_lockClicked{
    [self presentViewController:[[secondViewController alloc]init] animated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
