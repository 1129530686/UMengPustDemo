//
//  AppDelegate.h
//  goodfixpush
//
//  Created by 潘强 on 2018/9/30.
//  Copyright © 2018年 pan. All rights reserved.
//

#import <UIKit/UIKit.h>
//协议
@protocol getBaseurlDelegate <NSObject>
-(void)didGetPushNotifi;
@end
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

//属性
@property (nonatomic,strong) NSDictionary* userInfo;        //友盟推送信息，跳转到指定页面
@property (nonatomic,strong) id<getBaseurlDelegate> delegate;  //代理

@end

