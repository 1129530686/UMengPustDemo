//
//  secondViewController.h
//  goodfixpush
//
//  Created by pan on 2018/10/11.
//  Copyright © 2018年 pan. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface secondViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
